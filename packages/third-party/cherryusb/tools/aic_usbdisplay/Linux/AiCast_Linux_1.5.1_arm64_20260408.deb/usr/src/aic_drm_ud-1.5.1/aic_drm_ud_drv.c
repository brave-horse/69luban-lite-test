// SPDX-License-Identifier: GPL-2.0-only
/*
 * Copyright (C) 2024-2026 ArtInChip Technology Co., Ltd.
 *
 * Authors: matteo <duanmt@artinchip.com>
 */

#include <linux/version.h>
#include <linux/module.h>

#include <drm/drm_crtc_helper.h>
#include <drm/drm_drv.h>
#include <drm/drm_fb_helper.h>
#include <drm/drm_file.h>
#include <drm/drm_gem_shmem_helper.h>
#include <drm/drm_modeset_helper.h>
#if LINUX_VERSION_CODE >= KERNEL_VERSION(5, 8, 0) || defined(EL8)
#include <drm/drm_managed.h>
#endif
#include <drm/drm_ioctl.h>
#include <drm/drm_probe_helper.h>
#include <drm/drm_print.h>
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 14, 0))
#include <drm/clients/drm_client_setup.h>
#include <drm/drm_fbdev_shmem.h>
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0))
#include <drm/drm_client_setup.h>
#include <drm/drm_fbdev_shmem.h>
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0))
#include <drm/drm_fbdev_shmem.h>
#elif (LINUX_VERSION_CODE > KERNEL_VERSION(6, 2, 0))
#include <drm/drm_fbdev_generic.h>
#endif

#include "aic_drm_ud_drv.h"

static int aic_ud_usb_suspend(struct usb_interface *interface,
			      pm_message_t message)
{
	struct drm_device *dev = usb_get_intfdata(interface);

	return drm_mode_config_helper_suspend(dev);
}

static int aic_ud_usb_resume(struct usb_interface *interface)
{
	struct drm_device *dev = usb_get_intfdata(interface);

	return drm_mode_config_helper_resume(dev);
}

static int aic_ud_gem_shmem_dumb_create(struct drm_file *file, struct drm_device *dev,
					struct drm_mode_create_dumb *args)
{
	struct drm_mode_create_dumb dumb = *args;
	int ret = 0;

	if (!(args->width % 64))
		return drm_gem_shmem_dumb_create(file, dev, args);

	dumb.width = round_up(args->width, 64);
	ret = drm_gem_shmem_dumb_create(file, dev, &dumb);

	args->pitch = dumb.pitch;
	args->size = dumb.size;
	args->handle = dumb.handle;
	DRM_DEBUG("Create FB: %d x %d, pitch %d, size %d\n",
		  args->width, args->height, args->pitch, (int)args->size);
	return ret;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(6, 10, 0))
static int aic_ud_gem_mmap(struct drm_gem_object *obj, struct vm_area_struct *vma)
{
	int ret;

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)) || \
    (LINUX_VERSION_CODE > KERNEL_VERSION(5, 15, 60) && LINUX_VERSION_CODE < KERNEL_VERSION(5, 16, 0))
	ret = drm_gem_shmem_mmap(to_drm_gem_shmem_obj(obj), vma);
#else
	ret = drm_gem_shmem_mmap(obj, vma);
#endif
	if (ret)
		return ret;

	if (obj->import_attach)
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 3, 0))
		vm_flags_set(vma, VM_DONTEXPAND);
#else
		vma->vm_flags |= VM_DONTEXPAND;
#endif

	return 0;
}

static const struct drm_gem_object_funcs aic_ud_gem_funcs = {
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0)) || \
    (LINUX_VERSION_CODE > KERNEL_VERSION(5, 15, 60) && LINUX_VERSION_CODE < KERNEL_VERSION(5, 16, 0))
	.free = drm_gem_shmem_object_free,
	.print_info = drm_gem_shmem_object_print_info,
	.pin = drm_gem_shmem_object_pin,
	.unpin = drm_gem_shmem_object_unpin,
	.get_sg_table = drm_gem_shmem_object_get_sg_table,
	.vmap = drm_gem_shmem_object_vmap,
	.vunmap = drm_gem_shmem_object_vunmap,
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 18, 0))
	.vm_ops = &drm_gem_shmem_vm_ops,
#endif
#else
	.free = drm_gem_shmem_free_object,
	.print_info = drm_gem_shmem_print_info,
	.pin = drm_gem_shmem_pin,
	.unpin = drm_gem_shmem_unpin,
	.get_sg_table = drm_gem_shmem_get_sg_table,
	.vmap = drm_gem_shmem_vmap,
	.vunmap = drm_gem_shmem_vunmap,
#endif
	.mmap = aic_ud_gem_mmap,
};

static struct drm_gem_object *aic_ud_gem_create_object(struct drm_device *dev, size_t size)
{
	struct drm_gem_shmem_object *shmem;

	shmem = kzalloc(sizeof(*shmem), GFP_KERNEL);
	if (!shmem)
		return ERR_PTR(-ENOMEM);

	shmem->base.funcs = &aic_ud_gem_funcs;

	return &shmem->base;
}
#endif

#if (LINUX_VERSION_CODE < KERNEL_VERSION(6, 16, 0))
static struct drm_gem_object *aic_ud_gem_prime_import(struct drm_device *dev,
						      struct dma_buf *dma_buf)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	if (!ud->dmadev)
		return ERR_PTR(-ENODEV);

	return drm_gem_prime_import_dev(dev, dma_buf, ud->dmadev);
}
#endif

static int aic_ud_ioctl_get_fmt(struct drm_device *dev, void *data,
				struct drm_file *file_priv)
{
	struct aic_ud_dev *ud = to_aic_ud(dev);

	memcpy(data, &ud->dev_para, sizeof(struct aic_ud_dev_para));

	return 0;
}

#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 8, 0))
static void aic_ud_driver_release(struct drm_device *dev)
{
	drm_kms_helper_poll_fini(dev);
	aic_ud_drop_usb(dev);
	drm_dev_fini(dev);
	kfree(dev);
}
#endif

static const struct drm_ioctl_desc aic_ud_ioctls[] = {
	DRM_IOCTL_DEF_DRV(AIC_UD_GET_FMT, aic_ud_ioctl_get_fmt,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_GEM_CREATE, aic_ud_ioctl_gem_create,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_GEM_DESTROY, aic_ud_ioctl_gem_destroy,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_WAIT_UPDATE, aic_ud_ioctl_wait_update,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_UPDATE_DONE, aic_ud_ioctl_update_done,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_RENDER_DONE, aic_ud_ioctl_render_done,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_SEND_DATA, aic_ud_ioctl_send_data,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_RECV_DATA, aic_ud_ioctl_recv_data,
			  DRM_RENDER_ALLOW),
	DRM_IOCTL_DEF_DRV(AIC_UD_AUTH_PASS, aic_ud_ioctl_auth_pass,
			  DRM_RENDER_ALLOW),
};

#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 11, 0))
const struct vm_operations_struct aic_gem_vm_ops = {
	.open = drm_gem_vm_open,
	.close = drm_gem_vm_close,
};
#endif

DEFINE_DRM_GEM_FOPS(aic_ud_driver_fops);

static struct drm_driver aic_ud_drm_driver = {
	.driver_features	= DRIVER_ATOMIC | DRIVER_GEM | DRIVER_MODESET,
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 8, 0))
	.release		= aic_ud_driver_release,
#endif
	/* GEM hooks */
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 11, 0)) && (LINUX_VERSION_CODE < KERNEL_VERSION(6, 10, 0))
	.gem_create_object	= aic_ud_gem_create_object,
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 9, 0)) && (LINUX_VERSION_CODE < KERNEL_VERSION(5, 11, 0))
	.gem_create_object	= drm_gem_shmem_create_object_cached,
#endif
#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 11, 0))
	.gem_close_object	= aic_ud_gem_close_object,
	.gem_vm_ops		= &aic_gem_vm_ops,
#endif

	.ioctls			= aic_ud_ioctls,
	.num_ioctls		= ARRAY_SIZE(aic_ud_ioctls),
	.fops			= &aic_ud_driver_fops,
	DRM_GEM_SHMEM_DRIVER_OPS,
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0))
	DRM_FBDEV_SHMEM_DRIVER_OPS,
#endif
#if (LINUX_VERSION_CODE < KERNEL_VERSION(6, 16, 0))
	.gem_prime_import	= aic_ud_gem_prime_import,
#endif

	.name	= DRIVER_NAME,
	.desc	= DRIVER_DESC,
#if (LINUX_VERSION_CODE < KERNEL_VERSION(6, 14, 0))
	.date	= DRIVER_DATE,
#endif
	.major	= DRIVER_MAJOR,
	.minor	= DRIVER_MINOR,
	.patchlevel = DRIVER_PATCHLEVEL,
};

#if (LINUX_VERSION_CODE < KERNEL_VERSION(5, 8, 0))
static void *__devm_drm_dev_alloc(struct device *parent,
				  struct drm_driver *driver,
				  size_t size, size_t offset)
{
	void *container;
	struct drm_device *drm;
	int ret;

	container = kzalloc(size, GFP_KERNEL);
	if (!container)
		return ERR_PTR(-ENOMEM);

	drm = container + offset;
	ret = devm_drm_dev_init(parent, drm, driver);
	if (ret) {
		kfree(container);
		return ERR_PTR(ret);
	}

	return container;
}
#define devm_drm_dev_alloc(parent, driver, type, member) \
	((type *) __devm_drm_dev_alloc(parent, driver, sizeof(type), \
				       offsetof(type, member)))
#endif

static struct aic_ud_dev *aic_ud_drv_create(struct usb_interface *interface)
{
	struct usb_device *udev = interface_to_usbdev(interface);
	struct aic_ud_dev *ud = NULL;
	int ret = 0;

	aic_ud_drm_driver.dumb_create = aic_ud_gem_shmem_dumb_create;
	ud = devm_drm_dev_alloc(&interface->dev, &aic_ud_drm_driver,
				struct aic_ud_dev, drm);
	if (IS_ERR(ud))
		return ud;

	ud->udev = udev;

	ret = aic_ud_init(ud);
	if (ret)
		return ERR_PTR(ret);

	usb_set_intfdata(interface, ud);

	return ud;
}

static int aic_ud_usb_probe(struct usb_interface *interface,
			    const struct usb_device_id *id)
{
	struct aic_ud_dev *ud = NULL;
	int ret = 0;

	ud = aic_ud_drv_create(interface);
	if (IS_ERR(ud))
		return PTR_ERR(ud);

	ret = drm_dev_register(&ud->drm, 0);
	if (ret)
		return ret;

	DRM_INFO("Init ArtInChip USB Display on minor %d\n",
		 ud->drm.primary->index);

#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0))
	drm_client_setup(&ud->drm, NULL);
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 11, 0))
	drm_fbdev_shmem_setup(&ud->drm, 0);
#else
	drm_fbdev_generic_setup(&ud->drm, 0);
#endif

	return 0;
}

static void aic_ud_usb_disconnect(struct usb_interface *interface)
{
	struct drm_device *dev = usb_get_intfdata(interface);

	drm_kms_helper_poll_fini(dev);
	aic_ud_drop_usb(dev);
	drm_dev_unplug(dev);
}

static const struct usb_device_id id_table[] = {
	{ USB_DEVICE_AND_INTERFACE_INFO(0x33C3, 0x0E01, USB_CLASS_VENDOR_SPEC, 0, 0) },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x33C3, 0x0E02, USB_CLASS_VENDOR_SPEC, 0, 0) },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x33C3, 0x0E04, USB_CLASS_VENDOR_SPEC, 0, 0) },
	{ USB_DEVICE_AND_INTERFACE_INFO(0x33C3, 0x0E05, USB_CLASS_VENDOR_SPEC, 0, 0) },
	{},
};
MODULE_DEVICE_TABLE(usb, id_table);

static struct usb_driver aic_ud_driver = {
	.name = DRIVER_NAME,
	.probe = aic_ud_usb_probe,
	.disconnect = aic_ud_usb_disconnect,
	.suspend = aic_ud_usb_suspend,
	.resume = aic_ud_usb_resume,
	.id_table = id_table,
};
module_usb_driver(aic_ud_driver);
#if (LINUX_VERSION_CODE >= KERNEL_VERSION(6, 13, 0))
MODULE_IMPORT_NS("DMA_BUF");
#elif (LINUX_VERSION_CODE >= KERNEL_VERSION(5, 17, 0))
MODULE_IMPORT_NS(DMA_BUF);
#endif
MODULE_LICENSE("GPL");
