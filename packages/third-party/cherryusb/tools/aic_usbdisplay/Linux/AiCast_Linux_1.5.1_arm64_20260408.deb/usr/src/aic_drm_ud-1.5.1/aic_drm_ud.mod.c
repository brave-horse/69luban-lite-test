#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};



static const struct modversion_info ____versions[]
__used __section("__versions") = {
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v33C3p0E01d*dc*dsc*dp*icFFisc00ip00in*");
MODULE_ALIAS("usb:v33C3p0E02d*dc*dsc*dp*icFFisc00ip00in*");
MODULE_ALIAS("usb:v33C3p0E04d*dc*dsc*dp*icFFisc00ip00in*");
MODULE_ALIAS("usb:v33C3p0E05d*dc*dsc*dp*icFFisc00ip00in*");

MODULE_INFO(srcversion, "1B6781564C7EB319AB48ACA");
